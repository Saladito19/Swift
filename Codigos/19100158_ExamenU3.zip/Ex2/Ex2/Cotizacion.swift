//
//  Cotizacion.swift
//  Ex2
//
//  Created by OdioMac on 22/04/24.
//

import Foundation
class Cotizacion {
    //Atributos
    private var precioTotal:Int
    private var enganche:Int
    private var tasaAnual:Int
    private var plazo:Int
    init(_ precioTotal: Int,_ enganche: Int,_ tasaAnual:Int,_ plazo:Int) {
        self.precioTotal = precioTotal
        self.enganche = enganche
        self.tasaAnual = tasaAnual
        self.plazo = plazo
    }
    //Propiedades
    var PrecioTotal:Int{
        get{return precioTotal}
        set{precioTotal = newValue}
    }
    var Enganche:Int{
        get{return enganche}
        set{enganche = newValue}
    }
    var TasaAnual:Int{
        get{return tasaAnual}
        set{tasaAnual = newValue}
    }
    var Plazo:Int{
        get{return plazo}
        set{plazo = newValue}
    }
    //Metodo
    func CalcularMensualidad() -> Double{
        let TasaMensual = Double(TasaAnual)/12/100
        let MontoCredito = PrecioTotal - Enganche
        let Mensualidad = TasaMensual * Double(MontoCredito) / (1 - pow((1 + TasaMensual), -Double(Plazo)) )
        return (Mensualidad * 100).rounded() / 100
    }
}

//
//  ViewController.swift
//  Ex2
//
//  Created by OdioMac on 22/04/24.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource  {

    
    @IBOutlet weak var SliderPlazo: UISlider!
    @IBOutlet weak var lblMensualidad: UILabel!
    @IBOutlet weak var lblPlazo: UILabel!
    @IBOutlet weak var lblEnganche: UILabel!
    @IBOutlet weak var imgAutos: UIImageView!
    @IBOutlet weak var pkvAutos: UIPickerView!
    var Autos = ["Compacto $500,000","Familiar $700,000","Deportivo $950,000"], AutoSeleccionado = 0, Enganche = 0, Plazo = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        pkvAutos.delegate = self
        pkvAutos.dataSource = self
        lblEnganche.text = (" Monto de enganche:  $\(Double(500000) * 0.2)")
        imgAutos.image = UIImage(named: "Compacto")
    }
    
    //Numero de componentes (columnas)
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    //Numero de renglones
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Autos.count
    }
    
    //Indicar el contenido de cada fila
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Autos[row]
    }
    
    //Obtener valor seleccionado
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch row {
        case 0: AutoSeleccionado = 500000
                imgAutos.image = UIImage(named: "Compacto")
            case 1: AutoSeleccionado = 700000
            imgAutos.image = UIImage(named: "Familiar")
            case 2: AutoSeleccionado = 950000
            imgAutos.image = UIImage(named: "Deportivo")
            default: print("Error")
        }
        //Se puede usar el switch
        //imgColor.image = UIImage(named: colores[row])
    }
    
    
    @IBAction func SeleccionarEnganche(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0: lblEnganche.text =  (" Monto de enganche:  $\(Double(AutoSeleccionado) * 0.2)")
            Enganche = Int((Double(AutoSeleccionado) * 0.2))
        case 1: lblEnganche.text = (" Monto de enganche:  $\(Double(AutoSeleccionado) * 0.3)")
            Enganche = Int((Double(AutoSeleccionado) * 0.3))
        case 2: lblEnganche.text = (" Monto de enganche:  $\(Double(AutoSeleccionado) * 0.4)")
            Enganche = Int((Double(AutoSeleccionado) * 0.4))
        case 3: lblEnganche.text = (" Monto de enganche:  $\(Double(AutoSeleccionado) * 0.5)")
            Enganche = Int((Double(AutoSeleccionado) * 0.5))
        default: print("Error")
        }
    }
    
    
    @IBAction func PlazoSeleccionado(_ sender: UISlider) {
        Plazo = Int(sender.value)
        lblPlazo.text = ("Plazo: \(Plazo)")
    }
    
    
    @IBAction func btnCalcular(_ sender: UIButton) {
        let miCotizacion = Cotizacion(AutoSeleccionado, Enganche,12 ,Plazo)
        lblMensualidad.text = "Mensualidad: \(miCotizacion.CalcularMensualidad())"
    }
    
}
